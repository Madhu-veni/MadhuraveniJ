import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';

void main() {
  runApp(CognitiveTestsApp());
}

class CognitiveTestsApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Cognitive Tests',
      theme: ThemeData(primarySwatch: Colors.purple),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cognitive Tests')),
      body: Center(
        // Centering the content on the screen
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Vertically centering
            crossAxisAlignment:
                CrossAxisAlignment.center, // Horizontally centering
            children: [
              Text(
                'Welcome to Cognitive Tests',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              Text(
                'Choose a test to start:',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ShapeIdentificationTest()),
                  );
                },
                child: Text('Shape Identification Test'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => MemoryTest()),
                  );
                },
                child: Text('Memory Test'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ColorMatchingTest()),
                  );
                },
                child: Text('Color Matching Test'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ShapeIdentificationTest extends StatefulWidget {
  @override
  _ShapeIdentificationTestState createState() =>
      _ShapeIdentificationTestState();
}

class _ShapeIdentificationTestState extends State<ShapeIdentificationTest> {
  final List<Map<String, dynamic>> questions = [
    {
      'image': Icons.star,
      'options': ['Circle', 'Square', 'Star', 'Triangle'],
      'answer': 'Star'
    },
    {
      'image': Icons.circle,
      'options': ['Circle', 'Pentagon', 'Hexagon', 'Square'],
      'answer': 'Circle'
    },
    {
      'image': Icons.change_history,
      'options': ['Circle', 'Triangle', 'Octagon', 'Star'],
      'answer': 'Triangle'
    },
  ];

  int currentQuestion = 0;
  int score = 0;
  bool showResult = false;
  bool isCorrect = false;
  Color backgroundColor = Colors.white;

  void checkAnswer(String selectedOption) {
    setState(() {
      isCorrect = questions[currentQuestion]['answer'] == selectedOption;
      if (isCorrect) {
        score++;
        backgroundColor = Colors.green;
      } else {
        backgroundColor = Colors.red;
      }

      Future.delayed(Duration(seconds: 1), () {
        setState(() {
          if (currentQuestion < questions.length - 1) {
            currentQuestion++;
            backgroundColor = Colors.white;
          } else {
            showResult = true;
          }
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Shape Identification Test')),
      body: Center(
        // Center the content of ShapeIdentificationTest
        child: AnimatedContainer(
          duration: Duration(milliseconds: 500),
          color: backgroundColor,
          child: showResult
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Test Completed!',
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Your Score: $score/${questions.length}',
                        style: TextStyle(fontSize: 20),
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Go Back'),
                      ),
                    ],
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Identify the Shape',
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 20),
                      Icon(
                        questions[currentQuestion]['image'],
                        size: 100,
                      ),
                      SizedBox(height: 20),
                      ...questions[currentQuestion]['options']
                          .map<Widget>((option) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: ElevatedButton(
                            onPressed: () => checkAnswer(option),
                            child: Text(option),
                          ),
                        );
                      }).toList(),
                      SizedBox(height: 20),
                      Text('Score: $score', style: TextStyle(fontSize: 18)),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}

class MemoryTest extends StatefulWidget {
  @override
  _MemoryTestState createState() => _MemoryTestState();
}

class _MemoryTestState extends State<MemoryTest> {
  List<int> numbers = [];
  List<int> userAnswers = [];
  Color backgroundColor = Colors.white;
  bool isCorrect = false;
  bool showNumbers = true;
  TextEditingController controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _generateRandomNumbers();
    Future.delayed(Duration(seconds: 5), () {
      setState(() {
        showNumbers = false;
      });
    });
  }

  void _generateRandomNumbers() {
    numbers = List.generate(5, (index) => index + 1);
    numbers.shuffle(Random());
  }

  void checkAnswers() {
    setState(() {
      List<int> userInput = controller.text
          .split(' ')
          .map((e) => int.tryParse(e.trim()) ?? 0)
          .toList();

      isCorrect = numbers.length == userInput.length &&
          numbers.every((num) => userInput.contains(num));
      backgroundColor = isCorrect ? Colors.green : Colors.red;

      Future.delayed(Duration(seconds: 2), () {
        setState(() {
          backgroundColor = Colors.white;
          if (isCorrect) {
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: Text('Correct!'),
                content: Text('You remembered the sequence correctly!'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('OK'),
                  ),
                ],
              ),
            );
          } else {
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: Text('Try Again!'),
                content: Text('The correct sequence was: ${numbers.join(' ')}'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('OK'),
                  ),
                ],
              ),
            );
          }
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Memory Test')),
      body: AnimatedContainer(
        duration: Duration(milliseconds: 500),
        color: backgroundColor,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Memorize these numbers:',
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 10),
              showNumbers
                  ? Text(
                      numbers.join(' '),
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    )
                  : Container(),
              SizedBox(height: 20),
              Text(
                'Enter the numbers in the same order (without commas):',
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 10),
              TextField(
                controller: controller,
                decoration: InputDecoration(
                  hintText: 'Enter numbers here...',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: checkAnswers,
                child: Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ColorMatchingTest extends StatefulWidget {
  @override
  _ColorMatchingTestState createState() => _ColorMatchingTestState();
}

class _ColorMatchingTestState extends State<ColorMatchingTest> {
  final List<Map<String, dynamic>> colorQuestions = [
    {
      'text': 'Brown',
      'color': Colors.blue,
      'options': ['Brown', 'Blue'],
      'answer': 'Blue'
    },
    {
      'text': 'Red',
      'color': Colors.green,
      'options': ['Red', 'Green'],
      'answer': 'Green'
    },
    {
      'text': 'Yellow',
      'color': Colors.red,
      'options': ['Yellow', 'Red'],
      'answer': 'Red'
    },
    {
      'text': 'Green',
      'color': Colors.yellow,
      'options': ['Green', 'Yellow'],
      'answer': 'Yellow'
    },
    {
      'text': 'Purple',
      'color': Colors.orange,
      'options': ['Purple', 'Orange'],
      'answer': 'Orange'
    },
  ];

  int currentQuestion = 0;
  int score = 0;
  Color backgroundColor = Colors.white;

  void checkAnswer(String selectedOption) {
    setState(() {
      bool isCorrect =
          colorQuestions[currentQuestion]['answer'] == selectedOption;
      backgroundColor = isCorrect ? Colors.green : Colors.red;
      if (isCorrect) {
        score++;
      }

      Future.delayed(Duration(seconds: 1), () {
        setState(() {
          if (currentQuestion < colorQuestions.length - 1) {
            currentQuestion++;
            backgroundColor = Colors.white;
          } else {
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: Text('Test Completed!'),
                content: Text('Your Score: $score/${colorQuestions.length}'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.pop(context);
                    },
                    child: Text('OK'),
                  ),
                ],
              ),
            );
          }
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Color Matching Test')),
      body: AnimatedContainer(
        duration: Duration(milliseconds: 500),
        color: backgroundColor,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Choose the color',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              Text(
                colorQuestions[currentQuestion]['text'],
                style: TextStyle(
                    fontSize: 36,
                    color: colorQuestions[currentQuestion]['color']),
              ),
              SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: colorQuestions[currentQuestion]['options']
                    .map<Widget>((option) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: ElevatedButton(
                      onPressed: () => checkAnswer(option),
                      child: Text(option),
                    ),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              Text('Score: $score', style: TextStyle(fontSize: 18)),
            ],
          ),
        ),
      ),
    );
  }
}
