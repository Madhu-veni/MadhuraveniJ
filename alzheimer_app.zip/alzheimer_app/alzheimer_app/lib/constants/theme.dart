import 'package:flutter/material.dart';

const White = Color(0xffffffff);
const Black = Color(0xFF0D0D0D);
const darkBlue = Color(0xff1F1226);
const Red = Color(0xffF41E51);
const Darkpink = Color(0xFFD51141);
